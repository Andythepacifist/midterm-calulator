﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel2 = New Panel()
        Button32 = New Button()
        Button31 = New Button()
        Button30 = New Button()
        Button29 = New Button()
        Button28 = New Button()
        Button27 = New Button()
        Button26 = New Button()
        Button25 = New Button()
        Button24 = New Button()
        Button23 = New Button()
        Button22 = New Button()
        Button21 = New Button()
        Button20 = New Button()
        Button19 = New Button()
        Button18 = New Button()
        Button17 = New Button()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        TextBox1 = New TextBox()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(Button8)
        Panel2.Controls.Add(Button7)
        Panel2.Controls.Add(Button6)
        Panel2.Controls.Add(Button5)
        Panel2.Controls.Add(Button4)
        Panel2.Controls.Add(Button3)
        Panel2.Controls.Add(Button2)
        Panel2.Controls.Add(Button1)
        Panel2.Controls.Add(Button17)
        Panel2.Controls.Add(Button18)
        Panel2.Controls.Add(Button19)
        Panel2.Controls.Add(Button20)
        Panel2.Controls.Add(Button21)
        Panel2.Controls.Add(Button22)
        Panel2.Controls.Add(Button23)
        Panel2.Controls.Add(Button24)
        Panel2.Controls.Add(Button25)
        Panel2.Controls.Add(Button26)
        Panel2.Controls.Add(Button27)
        Panel2.Controls.Add(Button28)
        Panel2.Controls.Add(Button29)
        Panel2.Controls.Add(Button30)
        Panel2.Controls.Add(Button31)
        Panel2.Controls.Add(Button32)
        Panel2.Location = New Point(12, 82)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(488, 486)
        Panel2.TabIndex = 16
        ' 
        ' Button32
        ' 
        Button32.Font = New Font("Javanese Text", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button32.Location = New Point(0, 68)
        Button32.Name = "Button32"
        Button32.Size = New Size(116, 59)
        Button32.TabIndex = 0
        Button32.Text = "C"
        Button32.UseVisualStyleBackColor = True
        ' 
        ' Button31
        ' 
        Button31.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button31.Location = New Point(3, 149)
        Button31.Name = "Button31"
        Button31.Size = New Size(116, 59)
        Button31.TabIndex = 1
        Button31.Text = "7"
        Button31.UseVisualStyleBackColor = True
        ' 
        ' Button30
        ' 
        Button30.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button30.Location = New Point(125, 149)
        Button30.Name = "Button30"
        Button30.Size = New Size(116, 59)
        Button30.TabIndex = 2
        Button30.Text = "8"
        Button30.UseVisualStyleBackColor = True
        ' 
        ' Button29
        ' 
        Button29.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button29.Location = New Point(244, 68)
        Button29.Name = "Button29"
        Button29.Size = New Size(116, 59)
        Button29.TabIndex = 3
        Button29.Text = "x^2"
        Button29.UseVisualStyleBackColor = True
        ' 
        ' Button28
        ' 
        Button28.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button28.Location = New Point(247, 149)
        Button28.Name = "Button28"
        Button28.Size = New Size(116, 59)
        Button28.TabIndex = 4
        Button28.Text = "9"
        Button28.UseVisualStyleBackColor = True
        ' 
        ' Button27
        ' 
        Button27.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button27.Location = New Point(122, 68)
        Button27.Name = "Button27"
        Button27.Size = New Size(116, 59)
        Button27.TabIndex = 5
        Button27.Text = "√"
        Button27.UseVisualStyleBackColor = True
        ' 
        ' Button26
        ' 
        Button26.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button26.Location = New Point(366, 68)
        Button26.Name = "Button26"
        Button26.Size = New Size(116, 59)
        Button26.TabIndex = 6
        Button26.Text = "÷"
        Button26.UseVisualStyleBackColor = True
        ' 
        ' Button25
        ' 
        Button25.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button25.Location = New Point(366, 149)
        Button25.Name = "Button25"
        Button25.Size = New Size(116, 59)
        Button25.TabIndex = 7
        Button25.Text = "X"
        Button25.UseVisualStyleBackColor = True
        ' 
        ' Button24
        ' 
        Button24.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button24.Location = New Point(3, 234)
        Button24.Name = "Button24"
        Button24.Size = New Size(116, 59)
        Button24.TabIndex = 8
        Button24.Text = "4"
        Button24.UseVisualStyleBackColor = True
        ' 
        ' Button23
        ' 
        Button23.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button23.Location = New Point(247, 234)
        Button23.Name = "Button23"
        Button23.Size = New Size(116, 59)
        Button23.TabIndex = 9
        Button23.Text = "6"
        Button23.UseVisualStyleBackColor = True
        ' 
        ' Button22
        ' 
        Button22.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button22.Location = New Point(366, 234)
        Button22.Name = "Button22"
        Button22.Size = New Size(116, 59)
        Button22.TabIndex = 10
        Button22.Text = "-"
        Button22.UseVisualStyleBackColor = True
        ' 
        ' Button21
        ' 
        Button21.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button21.Location = New Point(125, 234)
        Button21.Name = "Button21"
        Button21.Size = New Size(116, 59)
        Button21.TabIndex = 11
        Button21.Text = "5"
        Button21.UseVisualStyleBackColor = True
        ' 
        ' Button20
        ' 
        Button20.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button20.Location = New Point(125, 309)
        Button20.Name = "Button20"
        Button20.Size = New Size(116, 59)
        Button20.TabIndex = 12
        Button20.Text = "2"
        Button20.UseVisualStyleBackColor = True
        ' 
        ' Button19
        ' 
        Button19.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button19.Location = New Point(0, 309)
        Button19.Name = "Button19"
        Button19.Size = New Size(116, 59)
        Button19.TabIndex = 13
        Button19.Text = "1"
        Button19.UseVisualStyleBackColor = True
        ' 
        ' Button18
        ' 
        Button18.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button18.Location = New Point(366, 309)
        Button18.Name = "Button18"
        Button18.Size = New Size(116, 59)
        Button18.TabIndex = 14
        Button18.Text = "+"
        Button18.UseVisualStyleBackColor = True
        ' 
        ' Button17
        ' 
        Button17.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button17.Location = New Point(247, 309)
        Button17.Name = "Button17"
        Button17.Size = New Size(116, 59)
        Button17.TabIndex = 15
        Button17.Text = "3"
        Button17.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(0, 393)
        Button1.Name = "Button1"
        Button1.Size = New Size(116, 59)
        Button1.TabIndex = 16
        Button1.Text = "0"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(125, 393)
        Button2.Name = "Button2"
        Button2.Size = New Size(116, 59)
        Button2.TabIndex = 17
        Button2.Text = "."
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(247, 393)
        Button3.Name = "Button3"
        Button3.Size = New Size(116, 59)
        Button3.TabIndex = 18
        Button3.Text = "<"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(366, 393)
        Button4.Name = "Button4"
        Button4.Size = New Size(116, 59)
        Button4.TabIndex = 19
        Button4.Text = "="
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button5.Location = New Point(3, 27)
        Button5.Name = "Button5"
        Button5.Size = New Size(116, 35)
        Button5.TabIndex = 20
        Button5.Text = "1/x"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button6.Location = New Point(122, 27)
        Button6.Name = "Button6"
        Button6.Size = New Size(116, 35)
        Button6.TabIndex = 21
        Button6.Text = "π"
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button7.Location = New Point(244, 27)
        Button7.Name = "Button7"
        Button7.Size = New Size(116, 35)
        Button7.TabIndex = 22
        Button7.Text = "^"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Font = New Font("Impact", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button8.Location = New Point(366, 27)
        Button8.Name = "Button8"
        Button8.Size = New Size(116, 35)
        Button8.TabIndex = 23
        Button8.Text = "!"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(12, 36)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(488, 27)
        TextBox1.TabIndex = 17
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(512, 574)
        Controls.Add(TextBox1)
        Controls.Add(Panel2)
        Name = "Form1"
        Text = "Form1"
        Panel2.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As TextBox

End Class
